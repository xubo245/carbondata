import sys
sys.path.append('../../')

from pycarbon.tests.im.test import print_string

if __name__ == '__main__':
    str = "hello"
    print_string(str)